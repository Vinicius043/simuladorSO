package so;

public enum SystemCallType {
	CREATE_PROCESS, WRITE_PROCESS, READ_PROCESS, DELETE_PROCESS, 
}
