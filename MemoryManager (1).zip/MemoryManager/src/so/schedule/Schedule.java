package so.schedule;

public class Schedule {

}
